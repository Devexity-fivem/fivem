fx_version 'cerulean'
game 'gta5'

author 'YourName'
description 'Vehicle Repair Script'
version '1.0.0'

server_scripts {
    'server/fix_car.lua'
}

client_scripts {
    'client/repair_vehicle.lua'
}
